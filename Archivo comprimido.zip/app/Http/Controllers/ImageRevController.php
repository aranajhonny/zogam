<?php

namespace App\Http\Controllers;

use App\Image_rev;
use Illuminate\Http\Request;

class ImageRevController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Image_rev  $image_rev
     * @return \Illuminate\Http\Response
     */
    public function show(Image_rev $image_rev)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Image_rev  $image_rev
     * @return \Illuminate\Http\Response
     */
    public function edit(Image_rev $image_rev)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Image_rev  $image_rev
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Image_rev $image_rev)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Image_rev  $image_rev
     * @return \Illuminate\Http\Response
     */
    public function destroy(Image_rev $image_rev)
    {
        //
    }
}
