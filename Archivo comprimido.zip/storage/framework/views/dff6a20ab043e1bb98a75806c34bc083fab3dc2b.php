<?php $__env->startSection('content'); ?>
<div class="container">
  <div class="row">
  <div class="col-md-12">
    <div class="text-right nuevo-veh">
      <a href="<?php echo e(url('/vehiculo/create')); ?>" class="btn btn-info"><span class="fa fa-truck"> NUEVO VEHICULO</span></a>
    </div>
  </div>
    <div class="col-md-12 ">
      <div class="panel panel-info">
        <div class="panel-heading">/ Home</div>
        <div class="panel-body">
          <div class="container">
            <div class="table-responsive">
              <table class="table"> 
               <caption>Vehiculos registrados</caption> 
               <thead> 
                 <tr> 
                   <th>#</th> 
                   <th>Placa</th> 
                   <th>Marca / Modelo</th> 
                   <th>Propietario</th> 
                   <th>Estatus</th>
                   <th>Acciones</th> 
                 </tr> 
               </thead>
               <tbody> 
                <?php $__currentLoopData = $autos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $auto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr> 
                  <th scope="row"><?php echo e($auto->id); ?></th> 
                  <td><?php echo e(strtoupper($auto->placa)); ?></td> 
                  <td><?php echo e(strtoupper($auto->marca)); ?> - <?php echo e(strtoupper($auto->modelo)); ?></td> 
                  <td><?php echo e(strtoupper($auto->propietario)); ?></td>
                  <td><?php echo e(strtoupper($auto->status)); ?></td>
                  <td>
                    <a href="<?php echo e(route('vehiculo.edit', $auto->id)); ?>" class="btn btn-warning btn-xs" title="Editar Registro del Vehículo"><i class="fa fa-edit"></i></a>
                    <?php if($auto->status == "completo"): ?>
                      <a class="btn btn-success btn-xs" title="Agregar revision al vehículo"><i class="fa fa-camera"></i>
                    </a>
                    <?php else: ?>
                    <a href="<?php echo e(url('revision')); ?>/<?php echo e($auto->id); ?>" class="btn btn-success btn-xs" title="Agregar revision al vehículo"><i class="fa fa-camera"></i>
                    </a>
                    <?php endif; ?>

                  </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody> 
            </table>

          </div>
        </div>
        <?php echo e($autos->links()); ?>

      </div>
    </div>
  </div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>