<?php $__env->startSection('content'); ?>
<div class="container-fluid">
  <div class="row">
    <?php if(Session::get('message')): ?>
    <div class="col-md-8 col-md-offset-2">
        <div class="alert alert-success alert-dismissable">
          <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
          <h5> <?php echo e(Session::get('message')); ?></h5>
        </div>
    </div>
    <?php endif; ?>
    <?php if(Session::get('errors')): ?>
    <div class="col-md-8 col-md-offset-2">
        <div class="alert alert-danger alert-dismissable">
          <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
          <h5>Complete los campos obligatorios.</h5>
        </div>
    </div>
    <?php endif; ?>
    <div class="col-md-8 col-md-offset-2">
    <div class="panel panel-info">
    <div class="panel-heading"><center> Editar vehiculo</center> </div>
    <div class="panel-body">
    <center><h3>Editar vehiculo</h3></center>
    <br>
     <form class="" action=" <?php echo e(url('/vehiculo')); ?>/<?php echo e($auto->id); ?>" method="post">

      <div class="form-group <?php if($errors->has('placa')): ?> has-error <?php endif; ?> col-md-6">
        <label for="">Placa</label>
        <input type="text" class="form-control" name="placa" value="<?php echo e($auto->placa); ?>" placeholder="Placa"><br>
        <?php if($errors->has('placa')): ?> <p class="help-block"> Este campo es requerido.</p> <?php endif; ?> <br>
      </div>

      <div class="form-group <?php if($errors->has('marca')): ?> has-error <?php endif; ?> col-md-6">
        <label for="">Marca</label>
        <input type="text" class="form-control" name="marca" value="<?php echo e($auto->marca); ?>" placeholder="marca"><br>
        <?php if($errors->has('marca')): ?> <p class="help-block"> Este campo es requerido.</p> <?php endif; ?> <br>
      </div>

      <div class="form-group <?php if($errors->has('modelo')): ?> has-error <?php endif; ?> col-md-6">
        <label for="">Modelo</label>
        <input type="text" class="form-control" name="modelo" value="<?php echo e($auto->modelo); ?>" placeholder="modelo"><br>
        <?php if($errors->has('modelo')): ?> <p class="help-block"> Este campo es requerido.</p> <?php endif; ?> <br>
      </div>

      <div class="form-group <?php if($errors->has('anio')): ?> has-error <?php endif; ?> col-md-6">
        <label for="">Año</label>
        <input type="text" class="form-control" name="anio" value="<?php echo e($auto->anio); ?>" placeholder="año"><br>
        <?php if($errors->has('anio')): ?> <p class="help-block"> Este campo es requerido.</p> <?php endif; ?> <br>
      </div>

      <div class="form-group <?php if($errors->has('serial_motor')): ?> has-error <?php endif; ?> col-md-6">
        <label for="">Serial del motor</label>
        <input type="text" class="form-control" name="serial_motor" value="<?php echo e($auto->serial_motor); ?>" placeholder="serial motor"><br>
        <?php if($errors->has('serial_motor')): ?> <p class="help-block"> Este campo es requerido.</p> <?php endif; ?> <br>
      </div>

      <div class="form-group <?php if($errors->has('serial_carro')): ?> has-error <?php endif; ?> col-md-6">
        <label for="">Serial de la carroceria</label>
        <input type="text" class="form-control" name="serial_carro" value="<?php echo e($auto->serial_carro); ?>" placeholder="serial carro"><br>
        <?php if($errors->has('serial_carro')): ?> <p class="help-block"> {Este campo es requerido.</p> <?php endif; ?> <br>
      </div>

      <div class="form-group <?php if($errors->has('color')): ?> has-error <?php endif; ?> col-md-6">
        <label for="">Color</label>
        <input type="text" class="form-control" name="color" value="<?php echo e($auto->color); ?>" placeholder="color"><br>
        <?php if($errors->has('color')): ?> <p class="help-block"> Este campo es requerido.</p> <?php endif; ?> <br>
      </div>

      <div class="form-group <?php if($errors->has('tipo')): ?> has-error <?php endif; ?> col-md-6">
        <label for="">Tipo de veh&iacuteculo</label>
        <input type="text" class="form-control" name="tipo" value="<?php echo e($auto->tipo); ?>" placeholder="tipo"><br>
        <?php if($errors->has('tipo')): ?> <p class="help-block"> Este campo es requerido.</p> <?php endif; ?> <br>
      </div>

      <div class="form-group <?php if($errors->has('propietario')): ?> has-error <?php endif; ?> col-md-6">
        <label for="">Propietario</label>
        <input type="text" class="form-control" name="propietario" value="<?php echo e($auto->propietario); ?>" placeholder="propietario"><br>
        <?php if($errors->has('propietario')): ?> <p class="help-block"> Este campo es requerido.</p> <?php endif; ?> <br>
      </div>

      <div class="form-group <?php if($errors->has('telf_prop')): ?> has-error <?php endif; ?> col-md-6">
      <label for="telefono">Tel&eacutefono</label>
        <input type="text" class="form-control" name="telf_prop" value="<?php echo e($auto->telf_prop); ?>" placeholder="telefono propietario"><br>
        <?php if($errors->has('telf_prop')): ?> <p class="help-block"> Este campo es requerido.</p> <?php endif; ?> <br>
      </div>

      <div class="form-group <?php if($errors->has('email_prop')): ?> has-error <?php endif; ?> col-md-6">
        <label for="">Correo electronico</label>
        <input type="text" class="form-control" name="email_prop" value="<?php echo e($auto->email_prop); ?>" placeholder="email propietario"><br>
        <?php if($errors->has('email_prop')): ?> <p class="help-block"> Este campo es requerido.</p> <?php endif; ?> <br>
      </div>

      <input type="hidden" name="_method" value="put">

      <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
      <div class="form-group <?php if($errors->has('name')): ?> has-error <?php endif; ?> col-md-2 col-md-offset-5">
      </div>
      <div class="row">
      <div class="col-md-12 text-center" style="margin-bottom: 50px;">
        <button type="submit" name="name" class="btn btn-success"><span class="fa fa-save"></span> Guardar</button>
        <button type="reset" name="Restaurar" class="btn btn-danger" ><span class="fa fa-refresh"></span> Restaurar</button>
        <br>
      </div>
      </div>
    </form>
  </div>
  </div>
  </div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>